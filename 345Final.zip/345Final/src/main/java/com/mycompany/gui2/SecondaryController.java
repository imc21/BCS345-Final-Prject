package com.mycompany.gui2;

import java.io.IOException;
import java.time.LocalTime;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;

public class SecondaryController {

    @FXML
    private Label weekTitle;
    @FXML
    private Label timeDisplay;
    
    @FXML
    private Label dayTitle;
    @FXML
    private Label selectDayTitle;
   
    @FXML
    private TableColumn<?, ?> rosterDisplay;
    @FXML
    private DatePicker selectDayDatePicker;
    @FXML
    private CheckBox editCheck1;
    @FXML
    private CheckBox editCheck2;
    @FXML
    private CheckBox editCheck3;
    @FXML
    private CheckBox editCheck4;
    @FXML
    private CheckBox editCheck5;
    @FXML
    private CheckBox editCheck6;
    @FXML
    private CheckBox editCheck7;
    @FXML
    private CheckBox editCheck8;
    @FXML
    private CheckBox editCheck9;
    @FXML
    private CheckBox editCheck10;
    @FXML
    private CheckBox editCheck11;
    @FXML
    private CheckBox editCheck12;
    @FXML
    private Button editScheduleButton;

    @FXML
    private void setCustomDayTable(ActionEvent event) {
    }

    @FXML
    private void editSchedule(ActionEvent event) {
    }
    
    
    
    
    
    
}